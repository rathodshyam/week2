import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigurationClass {
		@Bean
		Address getAddress(){
			return new Address();
		}
		
		@Bean
		@Qualifier("mno")
		Salary getSalary(){
			return new Salary();
		}
		
		

}
