
public class Location {
	private int lattitude;
	private int longitude;
	public int getLattitude() {
		return lattitude;
	}
	public void setLattitude(int lattitude) {
		this.lattitude = lattitude;
	}
	public int getLongitude() {
		return longitude;
	}
	public void setLongitude(int longitude) {
		this.longitude = longitude;
	}
	public Location(int lattitude, int longitude) {
		super();
		this.lattitude = lattitude;
		this.longitude = longitude;
	}
	
	public Location() {
		
	}
	@Override
	public String toString() {
		return "Location [lattitude=" + lattitude + ", longitude=" + longitude + "]";
	}
	
	
	
	

}
