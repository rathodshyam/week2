package com.example9.demoa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example9.demoa.model.Product;
import com.example9.demoa.repo.IProductRepository;

@Service
public class ProductService {

	
	@Autowired
	IProductRepository iProdRepo;
	
	public void addProduct(Product pd)
	{
		iProdRepo.save(pd);
	}
	
	public List<Product> getAllProducts(){
		return (List<Product>) iProdRepo.findAll();
	}
	
	public Product getProductById(long id) {
		// TODO Auto-generated method stub
		return iProdRepo.findById(id).get();
		
	}
	
	public void deleteProductById(long id) {
		
		 iProdRepo.deleteById(id);
		
	}
	
	public Product update(Product curProd,long id) {
		return iProdRepo.save(curProd);
	}
	
	

	
}
