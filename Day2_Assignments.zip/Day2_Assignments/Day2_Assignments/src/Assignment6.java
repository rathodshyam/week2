class Products{
	int id = 9;
	Products eg() {
		return null;
	}
}
public class Assignment6 {
	
	public static void main (String[] args) {
		Products p =  new Products();
		Products pro = p.eg();
		System.out.println(pro.id);
	}
	// NullPointerException is an unchecked exception
}
