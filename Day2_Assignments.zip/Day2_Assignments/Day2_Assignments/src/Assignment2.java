final class A{ //final can be used for class 
	final String name = "Sai Preethi";
	public final void met1() { // final can be used for method
		System.out.println("a.met1() "+name);
	}
}

class B{
	int id;// final can be used for local variable
	public void met2(){
		System.out.println("b.met2()");
	}
	
	public void met2(final int i) // final can be used for parameter
	{
		id = i;
		System.out.println(id);
	}
}
public class Assignment2 {
	
	public static void main(String[] args) {
		
		A a = new A();
		final B b = new B(); // final can be used for instance member
		a.met1();
		b.met2();
		b.met2(10);
		
	}

}
