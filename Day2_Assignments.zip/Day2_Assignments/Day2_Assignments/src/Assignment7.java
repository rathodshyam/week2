interface MyInterface{
	void met1();
	default int met2() {
		System.out.println("MyInterface.met2()");
		return 0;
	}
	static int met3() {
		System.out.println("MyInterface.met3()");
		return 0;
	}
}

class MyClass implements MyInterface{

	@Override
	public void met1() {
		// TODO Auto-generated method stub
		System.out.println("MyInterface.met1()");
	}
	
	public int met2() {   // overriding default method of interface by making it "public"
		System.out.println("overriden default method met2() of interface by making it public");
		return 1;
		
	}
	
}
public class Assignment7 {
	
	public static void main(String[] args) {
		MyClass obj = new MyClass();
		obj.met1();
		obj.met2();
	}

}
