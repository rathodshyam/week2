class Prod{
	int id = 9;
	Prod eg() {
		return null;
	}
}
public class Assignment5 {
	
	public static void main (String[] args) {
		Prod p[] = new Prod[100000* 10000];
		
		//we will get OutOfMemoryError when heap is full
	}


}
