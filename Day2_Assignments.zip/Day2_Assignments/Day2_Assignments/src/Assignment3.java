abstract class Ab
{
	void name() {
		System.out.println("Abstract class name() method");
	}
}


class ChildAb extends Ab
{
	void name()
	{
		System.out.println("Child of Abstract class name() method");
	}
}



interface Inter
{
	void method1();
	default int returnInt()
	{
		return 10;
	}
}


class Demo implements Inter
{

	public int returnInt()
	{
		return 5;
	}
	@Override
	public void method1() {
	// TODO Auto-generated method stub
		System.out.println("Implemented method of interface");
	}
}

public class Assignment3 {

	public static void main(String[] args) {
		//abstract class can be used as reference
		Ab a=new ChildAb();
		a.name();
		
		//interface can be used as reference
		Inter i=new Demo();
		System.out.println(i.returnInt());
		i.method1();
		}
}
