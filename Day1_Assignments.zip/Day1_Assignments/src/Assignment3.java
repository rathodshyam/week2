import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Products{
	int id;
	String name;
	float price;
	public Products(int id, String name, float price) {
	super();
	this.id = id;
	this.name = name;
	this.price = price;
	}
	}
public class Assignment3 {
	
	public static void main(String[] args) {
	List<Products> list = new ArrayList<Products>();
	list.add(new Products(1, "HP Laptop", 25000f));
	list.add(new Products(3, "Keyboard", 300f));
	list.add(new Products(2, "Dell Mouse", 150f));

	 System.out.println("Sorting on the basis of name...");

	Collections.sort(list, (p1, p2) -> p1.name.compareTo(p2.name));
	for (Products p : list) {
	System.out.println("name is: "+p.name+ "\nid is: " + p.id + "\nprice is " + p.price+"\n\n");
	}

}
	

}
