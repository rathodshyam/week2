import java.util.HashSet;
import java.util.TreeSet;

public class Assignment1 {

	public static void main(String[] args)
	{
	HashSet<String> hSet = new HashSet<>();
	hSet.add("Preethi");
	hSet.add("Vignesh");
	hSet.add("Ananya");
	hSet.add("Hasini");

	 TreeSet<String> tSet = new TreeSet<>();
	tSet.addAll(hSet);

	 for (String s:tSet) {
	System.out.println(s);
	}

	}
}
