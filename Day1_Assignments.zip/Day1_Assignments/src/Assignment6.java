import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

public class Assignment6 {

public static void main(String[] args) {
		
		TreeMap<String,List> tms = new TreeMap<String, List>();
		tms.put("Telangana", Arrays.asList("Hyderabad","Warangal","Nizamabad","Khammam"));
		tms.put("Tamil Nadu",Arrays.asList("Chennai","Coimbatore","Kanchipuram"));
		tms.put("Kerala", Arrays.asList("Trivendrum","Kochi"));

		
		Set<String> keys = tms.keySet();
		for(String key:keys) 
		System.out.println(key+"->"+tms.get(key));
		
	}
}
