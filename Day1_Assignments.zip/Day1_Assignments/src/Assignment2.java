
import java.util.TreeSet;

class Product{
	private int id;
	private float price;
	private String name;
	public Product(int id, float price, String name) {
		super();
		this.id = id;
		this.price = price;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", price=" + price + ", name=" + name + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}

public class Assignment2 {
	
	public static void main(String args[])
	{
		TreeSet<Product> ts = new TreeSet<>((p1, p2) ->p1.getName().compareTo(p2.getName()));

		ts.add(new Product(1,(float)100.0,"Oppo"));
		ts.add(new Product(2,(float)130.0,"Samsung"));
		ts.add(new Product(3,(float)1050.50,"Lenovo"));
		ts.add(new Product(4,(float)106.0,"Realme"));
		for(Product p:ts)
			System.out.println(p);
		
	}

}


