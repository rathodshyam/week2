import java.util.LinkedList;

public class Assignment4 {
	
public static void main(String[] args) {
		
		LinkedList<String> lls = new LinkedList<>();
		lls.add("New Delhi");
		lls.add("Mumbai");
		lls.add("Bangalore");
		lls.add("Hyderabad");
		lls.add("Chennai");
		
		lls.stream()
		.filter((str)->str.length()>6)
		.filter((str)->str.contains("D"))
		.forEach((e)-> System.out.println(e));
		
	}

}
